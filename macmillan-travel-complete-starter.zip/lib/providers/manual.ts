import type {ProviderAdapter,FlightSearchInput,FlightOffer} from "./types";
export const manualProvider:ProviderAdapter={name:"Manual",async search(_input:FlightSearchInput):Promise<FlightOffer[]>{return []}};
