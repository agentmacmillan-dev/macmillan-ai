export type FlightSearchInput={from:string;to:string;date:string;returnDate?:string;trip?:string};
export type FlightOffer={id:string;provider:string;airline:string;from:string;to:string;departure:string;arrival:string;stops:number;price:number;currency:string;baggage:string};
export interface ProviderAdapter { name:string; search(input:FlightSearchInput):Promise<FlightOffer[]>; getBooking?(id:string):Promise<unknown>; createBooking?(offerId:string,passengers:unknown[]):Promise<unknown>; cancelBooking?(id:string):Promise<unknown>; }
