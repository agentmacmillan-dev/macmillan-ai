import {manualProvider} from "./manual";
import type {FlightSearchInput,FlightOffer} from "./types";
const providers=[manualProvider];
export async function searchAllProviders(input:FlightSearchInput):Promise<FlightOffer[]>{const results=await Promise.all(providers.map(p=>p.search(input).catch(()=>[])));return results.flat();}
