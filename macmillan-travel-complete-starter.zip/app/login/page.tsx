import AuthForm from "@/components/AuthForm";
export default function Login(){return <main className="container" style={{padding:"70px 0",maxWidth:480}}><h1>Sign in</h1><AuthForm/></main>}
