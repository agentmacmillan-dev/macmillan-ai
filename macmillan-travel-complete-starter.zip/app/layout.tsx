import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "MACMILLAN TRAVEL",
  description: "Flights, travel packages and visa application support."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header style={{background:"white",borderBottom:"1px solid #e6edf1",position:"sticky",top:0,zIndex:20}}>
          <div className="container" style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px 0"}}>
            <Link href="/" style={{fontSize:22,fontWeight:900,color:"var(--brand)"}}>MACMILLAN TRAVEL</Link>
            <nav style={{display:"flex",gap:18,fontSize:14,fontWeight:700}}>
              <Link href="/flights">Flights</Link>
              <Link href="/visas">Visas</Link>
              <Link href="/dashboard">My Account</Link>
              <Link href="/admin">Admin</Link>
            </nav>
          </div>
        </header>
        {children}
        <footer style={{marginTop:60,padding:"36px 0",background:"#0e2029",color:"white"}}>
          <div className="container">
            <strong>MACMILLAN TRAVEL</strong>
            <p style={{opacity:.75}}>Travel booking and visa application support. Provider and government fees are subject to the applicable partner or authority.</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
