import FlightResults from "@/components/FlightResults";

export default async function Flights({searchParams}:{searchParams:Promise<Record<string,string|undefined>>}) {
  const q = await searchParams;
  return <main className="container" style={{padding:"44px 0"}}>
    <h1>Flight search</h1>
    <p style={{opacity:.7}}>Compare available offers. Live provider availability requires an enabled partner/API integration.</p>
    <FlightResults query={q}/>
  </main>
}
