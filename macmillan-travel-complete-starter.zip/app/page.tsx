import Link from "next/link";
import FlightSearch from "@/components/FlightSearch";

export default function Home() {
  return (
    <main>
      <section style={{background:"linear-gradient(135deg,#083b56,#0f766e)",color:"white",padding:"72px 0"}}>
        <div className="container">
          <p style={{fontWeight:800,letterSpacing:1}}>MACMILLAN TRAVEL</p>
          <h1 style={{fontSize:"clamp(38px,6vw,70px)",lineHeight:1.02,maxWidth:780,margin:"12px 0"}}>Plan your journey. Book with confidence.</h1>
          <p style={{fontSize:18,maxWidth:700,opacity:.9}}>Search flights, request travel packages and start visa applications from one place.</p>
          <div style={{marginTop:32}}><FlightSearch /></div>
        </div>
      </section>
      <section className="container" style={{padding:"54px 0"}}>
        <h2>Explore MACMILLAN TRAVEL</h2>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(230px,1fr))",gap:18,marginTop:20}}>
          {[
            ["Flights","Search one-way, return and multi-city trips.","/flights"],
            ["Visa services","Browse country requirements and submit applications.","/visas"],
            ["My bookings","View bookings, invoices and application status.","/dashboard"],
            ["Support","Contact the travel team for help.","/dashboard"]
          ].map(([title,text,href])=><Link className="card" href={href} key={title} style={{padding:22,color:"#10212b"}}><h3>{title}</h3><p style={{opacity:.72}}>{text}</p><span style={{color:"var(--brand)",fontWeight:800}}>Open →</span></Link>)}
        </div>
      </section>
    </main>
  );
}
