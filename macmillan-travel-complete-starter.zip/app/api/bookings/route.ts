import {NextResponse} from "next/server";
import {z} from "zod";
import {createClient} from "@/lib/supabase/server";
const schema=z.object({offerId:z.string().min(1),name:z.string().min(2),email:z.string().email()});
export async function POST(req:Request){const s=await createClient();const {data:{user}}=await s.auth.getUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});try{const body=schema.parse(await req.json());const reference=`MAC-${Date.now().toString(36).toUpperCase()}`;const {data,error}=await s.from("bookings").insert({user_id:user.id,reference,status:"pending_payment",provider:"manual",provider_booking_id:body.offerId,total_amount:0,currency:"XAF",contact_email:body.email}).select().single();if(error)throw error;return NextResponse.json({booking:data});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Booking failed"},{status:400});}}
