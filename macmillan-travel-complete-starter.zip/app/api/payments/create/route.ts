import {NextResponse} from "next/server";
export async function POST(){return NextResponse.json({error:"Payment provider not configured. Add Paystack, Flutterwave or Stripe credentials and implement the provider-specific checkout flow."},{status:501});}
