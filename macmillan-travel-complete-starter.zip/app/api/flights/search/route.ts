import {NextResponse} from "next/server";
import {z} from "zod";
import {searchAllProviders} from "@/lib/providers";
const schema=z.object({from:z.string().min(2),to:z.string().min(2),date:z.string().min(1),returnDate:z.string().optional(),trip:z.string().optional()});
export async function POST(req:Request){try{const input=schema.parse(await req.json());const offers=await searchAllProviders(input);return NextResponse.json({offers});}catch(e){return NextResponse.json({error:"Invalid flight search",details:e instanceof Error?e.message:"unknown"},{status:400});}}
