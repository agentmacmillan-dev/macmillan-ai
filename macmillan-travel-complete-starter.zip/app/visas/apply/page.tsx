import VisaApplicationForm from "@/components/VisaApplicationForm";
export default async function Apply({searchParams}:{searchParams:Promise<{type?:string}>}) {
 const q=await searchParams;
 return <main className="container" style={{padding:"44px 0",maxWidth:850}}><h1>Visa application</h1><p>Complete the application and upload requested documents. Final requirements are subject to the competent authority.</p><VisaApplicationForm visaTypeId={q.type||""}/></main>
}
