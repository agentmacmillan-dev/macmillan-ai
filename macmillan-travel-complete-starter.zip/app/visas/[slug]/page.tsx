import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
export default async function VisaCountry({params}:{params:Promise<{slug:string}>}) {
 const {slug}=await params; const supabase=await createClient();
 const {data:country}=await supabase.from("visa_countries").select("*").eq("slug",slug).single();
 if(!country) return <main className="container" style={{padding:"44px 0"}}><h1>Country not found</h1></main>;
 const {data:types}=await supabase.from("visa_types").select("*").eq("country_id",country.id).eq("is_active",true);
 return <main className="container" style={{padding:"44px 0",maxWidth:900}}><h1>{country.country_name} visa services</h1><p>{country.notes||"Review the requirements for your visa type."}</p>
 <div style={{display:"grid",gap:14,marginTop:24}}>{(types||[]).map(v=><div className="card" style={{padding:20}} key={v.id}><h2>{v.name}</h2><p>Processing: {v.processing_time||"Varies"} · Fee: {v.government_fee||"See authority"}</p><p>{v.requirements||"Requirements will be confirmed during application review."}</p><Link className="btn btn-primary" href={`/visas/apply?type=${v.id}`}>Apply</Link></div>)}</div></main>
}
