import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function Visas() {
 const supabase=await createClient();
 const {data}=await supabase.from("visa_countries").select("id,country_name,slug").eq("is_active",true).order("country_name");
 return <main className="container" style={{padding:"44px 0"}}>
  <h1>Visa services</h1><p>Requirements and application support by destination.</p>
  <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:14,marginTop:22}}>
   {(data||[]).map(c=><Link className="card" style={{padding:18,color:"#10212b"}} key={c.id} href={`/visas/${c.slug}`}><strong>{c.country_name}</strong><p style={{opacity:.7}}>View requirements →</p></Link>)}
  </div>
 </main>
}
