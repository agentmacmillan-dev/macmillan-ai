import BookingForm from "@/components/BookingForm";
export default async function Booking({searchParams}:{searchParams:Promise<{offer?:string}>}) {
  const q=await searchParams;
  return <main className="container" style={{padding:"44px 0",maxWidth:800}}><h1>Complete booking</h1><BookingForm offerId={q.offer||""}/></main>
}
