# MACMILLAN TRAVEL

Full-stack Next.js + Supabase travel agency starter for flight search, bookings, visa applications and admin operations.

## 1. Create the project

```bash
npm install
cp .env.example .env.local
npm run dev
```

## 2. Create Supabase

Create a Supabase project, then open **SQL Editor** and run:

`supabase/migrations/001_initial.sql`

Create a **private** Storage bucket called `visa-documents`.

Add your Supabase URL and publishable key to `.env.local`.

## 3. Authentication

In Supabase Auth, enable:
- Email/password
- Google OAuth (optional)
- Phone OTP (optional)

Configure your production Site URL and redirect URLs.

## 4. Admin

New users are `customer` by default. After creating your own account, promote the account to admin from the Supabase SQL editor:

```sql
update public.profiles
set role='admin'
where id='YOUR_AUTH_USER_UUID';
```

Never expose the service-role key to the browser.

## 5. Flight providers

The adapter layer is in:

`lib/providers/`

The starter uses Manual mode and deliberately returns no live inventory.

To enable real booking:
1. Obtain a commercial/API agreement with the provider or a licensed GDS/aggregator.
2. Store credentials only as server-side environment variables or a secret manager.
3. Implement the provider's adapter.
4. Verify fare, availability, passenger rules, ticketing and refund rules before charging the customer.
5. Record the provider booking/ticket reference.

Supported provider records are pre-seeded for:
- Ethiopian Airlines
- Afrijet
- Satguru

## 6. Payments

The endpoint `/api/payments/create` is intentionally a safe placeholder.

Choose one provider:
- Paystack
- Flutterwave
- Stripe

Then implement:
- server-side checkout creation
- signed webhook verification
- idempotency
- payment status updates
- booking confirmation only after verified payment/provider confirmation

## 7. Visa services

The visa directory is database-driven. Add countries and visa types in `visa_countries` and `visa_types`.

The application workflow supports:
- customer submission
- document records
- agent/admin status changes
- status history

The platform is an application-support system. It does not itself issue visas.

## 8. Security checklist

Before production:
- Keep `SUPABASE_SERVICE_ROLE_KEY` server-only.
- Keep passport files in a private Storage bucket.
- Encrypt sensitive passport identifiers at rest using a proper KMS/Vault strategy; do not treat database obfuscation as encryption.
- Enable MFA for staff.
- Review every RLS policy.
- Add audit logs for staff access to sensitive records.
- Add rate limiting and bot protection.
- Configure backups and retention/deletion policies.
- Obtain appropriate privacy/consent terms for each jurisdiction.
- Do not collect documents you do not need.

## 9. Deploy to Vercel

Push this repository to GitHub.

In Vercel:
1. Import the GitHub repository.
2. Add all variables from `.env.local`.
3. Deploy.
4. Put the Vercel production URL into Supabase Auth URL configuration.
5. Add the production callback URLs for Google/other OAuth providers.

## 10. Phone-only GitHub workflow

On Android:
1. Create a GitHub repository named `macmillan-travel`.
2. Upload the files in this project, preserving folders.
3. Create the Supabase project in your mobile browser.
4. Paste `001_initial.sql` into Supabase SQL Editor and run it.
5. Add GitHub/Vercel environment variables.
6. Deploy.
7. Test signup, flight search, visa directory and admin access.
8. Only after testing, connect real payment and travel-provider credentials.

## Important

This project is a functional foundation, not a claim of live access to airline inventory or government visa systems. Real ticket issuance requires authorized provider access; visa decisions remain with the relevant authority.
