create extension if not exists pgcrypto;

create type public.user_role as enum ('customer','agent','support','admin');
create type public.booking_status as enum ('draft','pending_payment','confirmed','ticketed','cancelled','refunded');
create type public.visa_status as enum ('draft','submitted','under_review','additional_documents','processing','approved','rejected','cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role public.user_role not null default 'customer',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.travelers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  first_name text not null, last_name text not null, date_of_birth date,
  nationality text, passport_number_encrypted text, passport_expiry date,
  created_at timestamptz not null default now()
);

create table public.providers (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  code text unique not null,
  provider_type text not null default 'airline',
  integration_mode text not null default 'manual',
  api_base_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  reference text unique not null,
  provider_id uuid references public.providers(id),
  provider text,
  provider_booking_id text,
  status public.booking_status not null default 'draft',
  total_amount numeric(14,2) not null default 0,
  currency char(3) not null default 'XAF',
  contact_email text,
  contact_phone text,
  itinerary jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.booking_passengers (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  traveler_id uuid references public.travelers(id),
  first_name text not null, last_name text not null,
  date_of_birth date, nationality text,
  passport_number_encrypted text
);

create table public.tickets (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  ticket_number text,
  e_ticket_url text,
  issued_at timestamptz
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  booking_id uuid references public.bookings(id),
  visa_application_id uuid,
  provider text not null,
  provider_reference text,
  amount numeric(14,2) not null,
  currency char(3) not null,
  status text not null default 'pending',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.visa_countries (
  id uuid primary key default gen_random_uuid(),
  country_name text unique not null,
  slug text unique not null,
  notes text,
  is_active boolean not null default true
);

create table public.visa_types (
  id uuid primary key default gen_random_uuid(),
  country_id uuid not null references public.visa_countries(id) on delete cascade,
  name text not null,
  government_fee text,
  processing_time text,
  requirements text,
  is_active boolean not null default true
);

create table public.visa_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete restrict,
  visa_type_id uuid not null references public.visa_types(id),
  reference text unique not null,
  status public.visa_status not null default 'draft',
  full_name text not null,
  email text not null,
  phone text,
  nationality text not null,
  passport_number_encrypted text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.visa_documents (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.visa_applications(id) on delete cascade,
  document_type text not null,
  storage_path text not null,
  original_filename text,
  mime_type text,
  uploaded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.visa_status_history (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.visa_applications(id) on delete cascade,
  old_status public.visa_status,
  new_status public.visa_status not null,
  note text,
  changed_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  channel text not null,
  recipient text not null,
  subject text,
  message text not null,
  status text not null default 'queued',
  created_at timestamptz not null default now()
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  rating integer check (rating between 1 and 5),
  comment text,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.commissions (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.providers(id),
  booking_id uuid references public.bookings(id),
  percentage numeric(6,3),
  amount numeric(14,2),
  currency char(3),
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index bookings_user_id_idx on public.bookings(user_id);
create index visa_applications_user_id_idx on public.visa_applications(user_id);
create index visa_types_country_id_idx on public.visa_types(country_id);
create index travelers_user_id_idx on public.travelers(user_id);

insert into public.providers(name,code,provider_type,integration_mode) values
('Ethiopian Airlines','ET','airline','manual'),
('Afrijet','J7','airline','manual'),
('Satguru','SATGURU','agency','manual')
on conflict do nothing;

insert into public.visa_countries(country_name,slug,notes) values
('Equatorial Guinea','equatorial-guinea','Visa requirements should be confirmed with the competent authority.'),
('Nigeria','nigeria','Visa requirements should be confirmed with the competent authority.'),
('United States','united-states','Visa requirements should be confirmed with the competent authority.'),
('France','france','Visa requirements should be confirmed with the competent authority.')
on conflict do nothing;

-- Create profile rows automatically for new Auth users.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,full_name) values (new.id,coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- RLS
alter table public.profiles enable row level security;
alter table public.travelers enable row level security;
alter table public.providers enable row level security;
alter table public.bookings enable row level security;
alter table public.booking_passengers enable row level security;
alter table public.tickets enable row level security;
alter table public.payments enable row level security;
alter table public.visa_countries enable row level security;
alter table public.visa_types enable row level security;
alter table public.visa_applications enable row level security;
alter table public.visa_documents enable row level security;
alter table public.visa_status_history enable row level security;
alter table public.notifications enable row level security;
alter table public.reviews enable row level security;
alter table public.commissions enable row level security;
alter table public.audit_logs enable row level security;

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role in ('admin','agent','support'));
$$;

create policy "profiles own read" on public.profiles for select to authenticated using (id=auth.uid() or public.is_staff());
create policy "profiles own update" on public.profiles for update to authenticated using (id=auth.uid() or public.is_staff()) with check (id=auth.uid() or public.is_staff());

create policy "travelers own" on public.travelers for all to authenticated using (user_id=auth.uid() or public.is_staff()) with check (user_id=auth.uid() or public.is_staff());

create policy "providers public read" on public.providers for select to anon,authenticated using (is_active=true);
create policy "providers staff write" on public.providers for all to authenticated using (public.is_staff()) with check (public.is_staff());

create policy "bookings own" on public.bookings for select to authenticated using (user_id=auth.uid() or public.is_staff());
create policy "bookings create own" on public.bookings for insert to authenticated with check (user_id=auth.uid());
create policy "bookings staff update" on public.bookings for update to authenticated using (public.is_staff()) with check (public.is_staff());

create policy "booking passengers own" on public.booking_passengers for select to authenticated using (exists(select 1 from bookings b where b.id=booking_id and (b.user_id=auth.uid() or public.is_staff())));
create policy "booking passengers insert" on public.booking_passengers for insert to authenticated with check (exists(select 1 from bookings b where b.id=booking_id and b.user_id=auth.uid()));
create policy "tickets own" on public.tickets for select to authenticated using (exists(select 1 from bookings b where b.id=booking_id and (b.user_id=auth.uid() or public.is_staff())));

create policy "payments own" on public.payments for select to authenticated using (user_id=auth.uid() or public.is_staff());

create policy "visa countries public" on public.visa_countries for select to anon,authenticated using (is_active=true);
create policy "visa types public" on public.visa_types for select to anon,authenticated using (is_active=true);

create policy "visa own" on public.visa_applications for select to authenticated using (user_id=auth.uid() or public.is_staff());
create policy "visa create" on public.visa_applications for insert to authenticated with check (user_id=auth.uid());
create policy "visa staff update" on public.visa_applications for update to authenticated using (public.is_staff()) with check (public.is_staff());

create policy "visa docs own" on public.visa_documents for select to authenticated using (exists(select 1 from visa_applications v where v.id=application_id and (v.user_id=auth.uid() or public.is_staff())));
create policy "visa docs insert own" on public.visa_documents for insert to authenticated with check (exists(select 1 from visa_applications v where v.id=application_id and v.user_id=auth.uid()));
create policy "visa history own" on public.visa_status_history for select to authenticated using (exists(select 1 from visa_applications v where v.id=application_id and (v.user_id=auth.uid() or public.is_staff())));

create policy "notifications own" on public.notifications for select to authenticated using (user_id=auth.uid() or public.is_staff());
create policy "reviews published" on public.reviews for select to anon,authenticated using (is_published=true);
create policy "reviews own insert" on public.reviews for insert to authenticated with check (user_id=auth.uid());
create policy "reviews staff" on public.reviews for update to authenticated using (public.is_staff()) with check (public.is_staff());

create policy "commissions staff" on public.commissions for all to authenticated using (public.is_staff()) with check (public.is_staff());
create policy "audit staff" on public.audit_logs for select to authenticated using (public.is_staff());

-- Restrict direct client grants; service_role remains server-side.
revoke all on all tables in schema public from anon;
revoke all on all tables in schema public from authenticated;
grant select on public.providers,public.visa_countries,public.visa_types,public.reviews to anon,authenticated;
grant select,insert,update,delete on public.profiles,public.travelers,public.bookings,public.booking_passengers,public.tickets,public.payments,public.visa_applications,public.visa_documents,public.visa_status_history,public.notifications,public.reviews,public.commissions,public.audit_logs,public.providers,public.visa_countries,public.visa_types to authenticated;
