"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function FlightSearch() {
  const router = useRouter();
  const [trip, setTrip] = useState("roundtrip");
  const [from, setFrom] = useState("SSG");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [returnDate, setReturnDate] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const q = new URLSearchParams({ trip, from, to, date, returnDate });
    router.push(`/flights?${q.toString()}`);
  }

  return <form onSubmit={submit} className="card" style={{padding:18,color:"#10212b"}}>
    <div style={{display:"flex",gap:8,marginBottom:14,flexWrap:"wrap"}}>
      {["roundtrip","oneway","multicity"].map(x=><button type="button" key={x} className="btn btn-secondary" onClick={()=>setTrip(x)} style={{outline:trip===x?"2px solid var(--brand)":undefined}}>{x}</button>)}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:12}}>
      <div><label className="label">From</label><input className="input" value={from} onChange={e=>setFrom(e.target.value.toUpperCase())} placeholder="SSG"/></div>
      <div><label className="label">To</label><input className="input" value={to} onChange={e=>setTo(e.target.value.toUpperCase())} placeholder="Destination"/></div>
      <div><label className="label">Departure</label><input className="input" type="date" value={date} onChange={e=>setDate(e.target.value)}/></div>
      {trip==="roundtrip" && <div><label className="label">Return</label><input className="input" type="date" value={returnDate} onChange={e=>setReturnDate(e.target.value)}/></div>}
      <div style={{display:"flex",alignItems:"end"}}><button className="btn btn-primary" style={{width:"100%"}}>Search flights</button></div>
    </div>
  </form>
}
