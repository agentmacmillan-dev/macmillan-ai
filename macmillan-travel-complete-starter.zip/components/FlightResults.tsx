"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

type Offer={id:string;provider:string;airline:string;from:string;to:string;departure:string;arrival:string;stops:number;price:number;currency:string;baggage:string};

export default function FlightResults({query}:{query:Record<string,string|undefined>}) {
  const [offers,setOffers]=useState<Offer[]>([]);
  const [loading,setLoading]=useState(true);
  useEffect(()=>{ fetch("/api/flights/search",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(query)}).then(r=>r.json()).then(x=>setOffers(x.offers||[])).finally(()=>setLoading(false)); },[JSON.stringify(query)]);
  if(loading) return <p>Searching partner providers…</p>;
  if(!offers.length) return <div className="card" style={{padding:24}}>No live offers yet. Connect a provider API or use Manual Booking Mode in the admin dashboard.</div>;
  return <div style={{display:"grid",gap:14,marginTop:22}}>{offers.map(o=><div className="card" key={o.id} style={{padding:20,display:"grid",gridTemplateColumns:"1fr auto",gap:15}}>
    <div><strong>{o.airline}</strong><div>{o.from} → {o.to}</div><small>{o.departure} – {o.arrival} · {o.stops===0?"Nonstop":`${o.stops} stop(s)`} · {o.baggage}</small><div style={{marginTop:8,fontSize:12,opacity:.6}}>Provider: {o.provider}</div></div>
    <div style={{textAlign:"right"}}><strong>{o.currency} {o.price.toLocaleString()}</strong><br/><Link className="btn btn-primary" href={`/booking?offer=${encodeURIComponent(o.id)}`}>Select</Link></div>
  </div>)}</div>
}
