"use client";
import {useState} from "react";
import {createClient} from "@/lib/supabase/client";
export default function AuthForm(){const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [msg,setMsg]=useState("");
async function login(e:React.FormEvent){e.preventDefault();const s=createClient();const {error}=await s.auth.signInWithPassword({email,password});setMsg(error?error.message:"Signed in. Refresh the page.");}
async function signup(){const s=createClient();const {error}=await s.auth.signUp({email,password});setMsg(error?error.message:"Check your email to confirm your account.");}
return <div className="card" style={{padding:24}}><form onSubmit={login}><label className="label">Email</label><input className="input" type="email" required value={email} onChange={e=>setEmail(e.target.value)}/><div style={{height:12}}/><label className="label">Password</label><input className="input" type="password" required value={password} onChange={e=>setPassword(e.target.value)}/><div style={{height:18}}/><button className="btn btn-primary" style={{width:"100%"}}>Sign in</button></form><button className="btn btn-secondary" style={{width:"100%",marginTop:10}} onClick={signup}>Create account</button>{msg&&<p>{msg}</p>}</div>}
