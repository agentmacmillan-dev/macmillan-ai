"use client";
import {useState} from "react";
export default function VisaApplicationForm({visaTypeId}:{visaTypeId:string}) {
 const [form,setForm]=useState({full_name:"",email:"",phone:"",nationality:"",passport_number:""});
 const [file,setFile]=useState<File|null>(null); const [status,setStatus]=useState("");
 const set=(k:string,v:string)=>setForm({...form,[k]:v});
 async function submit(e:React.FormEvent){e.preventDefault();setStatus("Submitting…");const r=await fetch("/api/visas/applications",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...form,visa_type_id:visaTypeId})});const j=await r.json();setStatus(r.ok?`Application ${j.reference} submitted.`:(j.error||"Could not submit")); if(r.ok&&file){/* upload endpoint can be added after auth/session is established */}}
 return <form className="card" style={{padding:24}} onSubmit={submit}>
  {Object.entries({full_name:"Full name",email:"Email",phone:"Phone",nationality:"Nationality",passport_number:"Passport number"}).map(([k,l])=><div key={k} style={{marginBottom:12}}><label className="label">{l}</label><input className="input" required={k!=="phone"} type={k==="email"?"email":"text"} value={(form as any)[k]} onChange={e=>set(k,e.target.value)}/></div>)}
  <label className="label">Passport/document file</label><input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={e=>setFile(e.target.files?.[0]||null)}/>
  <p style={{fontSize:12,opacity:.7}}>Upload is stored privately after authentication. Do not email passport documents.</p>
  <button className="btn btn-primary">Submit application</button>{status&&<p>{status}</p>}
 </form>
}
