"use client";
import {useState} from "react";
export default function BookingForm({offerId}:{offerId:string}) {
 const [email,setEmail]=useState(""); const [name,setName]=useState(""); const [status,setStatus]=useState("");
 async function submit(e:React.FormEvent){e.preventDefault();setStatus("Creating booking…");const r=await fetch("/api/bookings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({offerId,name,email})});const j=await r.json();setStatus(r.ok?`Booking created: ${j.booking?.reference||"pending"}`:(j.error||"Booking failed"))}
 return <form className="card" style={{padding:24}} onSubmit={submit}>
  <p>Selected offer: <strong>{offerId||"manual selection"}</strong></p>
  <label className="label">Traveler name</label><input className="input" required value={name} onChange={e=>setName(e.target.value)}/>
  <div style={{height:12}}/>
  <label className="label">Email</label><input className="input" type="email" required value={email} onChange={e=>setEmail(e.target.value)}/>
  <div style={{height:18}}/><button className="btn btn-primary">Continue to payment</button>
  {status&&<p>{status}</p>}
 </form>
}
